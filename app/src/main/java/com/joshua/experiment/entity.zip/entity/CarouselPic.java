package com.joshua.craftsman.entity;

/**
 * ============================================================
 * <p>
 * 版 权 ： 吴奇俊  (c) 2017
 * <p>
 * 作 者 : 吴奇俊
 * <p>
 * 版 本 ： 1.0
 * <p>
 * 创建日期 ： 2017/5/26 9:41
 * <p>
 * 描 述 ：
 * <p>
 * ============================================================
 **/

public class CarouselPic {
    public String imgName;
    public String imgUrl;
    public String id;

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }

    public String getImgName() {
        return this.imgName;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgUrl() {
        return this.imgUrl;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

}